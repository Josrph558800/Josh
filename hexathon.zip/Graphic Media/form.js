function animateText(hi,spd) {
    const text = document.querySelector(".animated-text");
    const textContent = hi;
    let speed = spd
    text.textContent = "";
    for (let i = 0; i < textContent.length; i++) {
        setTimeout(function () {
            text.textContent += textContent[i];
        }, speed * i)
    }
}

const allIn = document.querySelectorAll('.input-group input');

allIn.forEach(foc => {
    foc.addEventListener("focus", () =>{
        
    });
    foc.addEventListener("blur", () =>{
        
    });
});

window.onload = ()=>{
    offLoad()
}

localStorage.setItem('loged', 'false')
localStorage.removeItem('prfImg');
localStorage.removeItem('un')
localStorage.removeItem('em')
localStorage.removeItem('pass')

