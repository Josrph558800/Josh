function validateForm(){
    const email = document.querySelector('#userN').value.trim();
    const password = document.querySelector('#password').value.trim();
 
    const em = document.querySelector('.un')
    const emL = document.querySelector('.un label')
    const sp = document.querySelector('.sp')
    const spL = document.querySelector('.sp label')
    
    if(email === ''){
        em.classList.add('error')
        animateText('invalid user name');
        setTimeout(() => {
            animateText('Input user name');
            em.classList.remove('error')     
        }, 1000);        
    }else if(email.length < 3){
        em.classList.add('error')
        animateText('invalid user name');
        setTimeout(() => {
            em.classList.remove('error')            
        }, 1000);        
    }else if(email.length > 20){
        em.classList.add('error')
        animateText('invalid user name');
        setTimeout(() => {
            em.classList.remove('error')         
        }, 1000);        
    }else if(password === ''){
        sp.classList.add('error')
        animateText('Invalid password');
        setTimeout(() => {
            sp.classList.remove('error')  
            animateText('Input password');     
        }, 1000);        
    }else if(password.length < 8){
        sp.classList.add('error')
        animateText('Passwor is too short');
        setTimeout(() => {
            sp.classList.remove('error')         
        }, 1000);        
    }else if(password === '12345678'){
        sp.classList.add('error')
        animateText('Passwor is too easy');
        setTimeout(() => {
            sp.classList.remove('error')        
        }, 1000);        
    }else{
        animateText('Please Wait...', 20);
        console.log('logged in as: ', email)
        console.log('password is: ', password)
        loading()
        setTimeout(() => {
            window.location.href = 'Recipies.html' 
            localStorage.setItem('loged', 'true')    
            localStorage.setItem('un', email)     
            localStorage.setItem('pass', password)  
        }, 1500);
    }
} 

const createAccountForm = document.querySelector('.max')

createAccountForm.addEventListener('submit', event => {
    event.preventDefault()
    validateForm()
})

animateText('Welcome Back',50);