function editable() {
    const paragraphs = document.querySelectorAll('.editable');
        paragraphs.forEach(paragraph => {
            paragraph.setAttribute('contenteditable', 'true');
        });
}

function offeditable() {
    const paragraphs = document.querySelectorAll('.editable');
        paragraphs.forEach(paragraph => {
            paragraph.setAttribute('contenteditable', 'false');
        });
}

const edit = document.querySelector(".edit")

edit.onclick = () =>{
    editable()
    togS()
    redt()
}

const saved = document.querySelector(".save")

saved.onclick = () =>{
    offeditable()
    togS()
    redt()
    loading()
}

function togS() {
    const save = document.querySelector(".save")
    save.classList.toggle('sout')
}

function redt() {
    const rdt = document.querySelector(".edit")
    rdt.classList.toggle('edhi')
}

function removewall() {
    imageHolder.innerHTML = ''
    imageHolder.classList.add('proXer')
}

navB();logout();

function errProf() {
    question('Profile photo error. Please change or remove it', () => {
        localStorage.removeItem('prfImg'); 
        removewall();
        imageHolder.innerHTML = '';
    }, () => {
        removewall();
        uploadButton.click();
    }, 'Remove', 'Change');
}

const uploadButton = document.getElementById('ub');
const imageHolder = document.getElementById('ih');

uploadButton.addEventListener('click', () => {
    const fileInput = document.createElement('input');
    fileInput.type = 'file';
    fileInput.accept = 'image/*';
    fileInput.addEventListener('change', (event) => {
        const selectedFile = event.target.files[0];
        if (selectedFile) {
            const reader = new FileReader();
            reader.addEventListener('load', () => {
                const imageDataURL = reader.result;
                const tempImg = new Image();
                tempImg.src = imageDataURL;
                tempImg.onload = function() {
                    localStorage.setItem('prfImg', imageDataURL);
                    const img = document.createElement('img');
                    img.className = 'profilePhoto';
                    img.src = imageDataURL;
                    imageHolder.innerHTML = '';
                    imageHolder.classList.remove('proXer');
                    img.onerror = () => {
                        errProf();
                    };
                    imageHolder.appendChild(img);
                };
                tempImg.onerror = () => {
                    errProf();
                };
            });
            reader.readAsDataURL(selectedFile);
        }
    });
    fileInput.click();
});

const storedImage = localStorage.getItem('prfImg');
if (storedImage) {
    const img = document.createElement('img');
    img.className = 'profilePhoto';
    img.src = storedImage;    
    imageHolder.innerHTML = '';
    imageHolder.classList.remove('proXer');
    img.onerror = () => {
        errProf();
    };
    imageHolder.appendChild(img);
}
const pint = document.querySelector(".pint")
imageHolder.addEventListener('click', () => {
        if(imageHolder.innerHTML !== '') {
            const xnit = document.querySelector(".imagePx");
            const pintx = document.querySelector(".iBack");
            const cam = document.querySelector(".cam");
            const del = document.querySelector(".del");
            const downloadButton = document.querySelector('.dwn');
            pint.classList.add("pinx")       
            xnit.innerHTML = imageHolder.innerHTML          
        pintx.onclick = ()=>{
            pint.classList.remove("pinx");
        }  
        cam.onclick = ()=>{
            uploadButton.click();
            pint.classList.remove("pinx");
        }  
        del.onclick = ()=>{
            question("Are you sure you want to delete your profile photo?",()=>{setTimeout(deleteIt,500)},()=>{},"Delete", "Cancel")
            function deleteIt() {
                localStorage.removeItem('prfImg');
                imageHolder.innerHTML = '';
                imageHolder.classList.add('proXer');
                pint.classList.remove("pinx");
            }
        }  
        downloadButton.onclick = ()=>{
        const profilePhoto = document.querySelector('.profilePhoto');
        if (profilePhoto) {
            const imageUrl = profilePhoto.src;
            const a = document.createElement('a');
            a.href = imageUrl;
            a.download = localStorage.getItem("un")+"’s profile";
            document.body.appendChild(a);
            a.click();
            document.body.removeChild(a);
        }
        }
        }
    });


const usernam = document.querySelector('.userNam');
const stun = localStorage.getItem('un');
usernam.innerHTML = stun

const emai = document.querySelector('.emaiL');
const stem = localStorage.getItem('em');
emai.innerHTML = stem;

if(usernam.innerHTML === ''){
    outL();
}else if(emai.innerHTML === ''){
    emai.innerHTML = stun+'@deres.com';
}


window.onload = ()=>{
    offLoad();
    getPass();
}

function getPass() {
    console.log(localStorage.getItem('un')+"'s"+" password is: "+localStorage.getItem('pass'))
}
