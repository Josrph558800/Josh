const scrlC = document.querySelectorAll('.scrollHolder')

scrlC.forEach(function(follow){
  follow.addEventListener('mousedown', function(event) {
    event.preventDefault();
    const startX = event.pageX - follow.offsetLeft;
    const scrollLeft = follow.scrollLeft;
  
    follow.addEventListener('mousemove', moveScroll);
  
    document.addEventListener('mouseup', function() {
      follow.removeEventListener('mousemove', moveScroll);
    });
  
    function moveScroll(event) {
      const x = event.pageX - follow.offsetLeft;
      const walk = (x - startX) * 2;
      follow.scrollLeft = scrollLeft - walk;
    }
  });
})

    window.onload = ()=>{
        const delayedLinks = document.querySelectorAll(".valv a");
    
    delayedLinks.forEach(link => {
        link.addEventListener("click", function(event) {
            event.preventDefault();

            setTimeout(function() {               
                window.location.href = link.getAttribute('href');
                setTimeout(function() {   
                    const body1 = document.querySelector('.body1')                            
                    body1.style.overflow = 'hidden'
            }, 250);
        }, 250);
    });
});

const out = document.querySelector('.out')

out.onclick = ()=>{
    body1.style.overflow = 'auto'
}
    }
    
const outx = document.querySelector('.out img')
const ouj = document.querySelector('.downBT')    
const infx = document.querySelector('.vbn')
const opd = document.querySelectorAll('.addBT')
opd.forEach((opdx)=>{
    opdx.onclick = ()=>{
        infx.classList.add('jjc')
    }
})
ouj.onclick = ()=>{
    infx.classList.remove('jjc')
}


outx.onclick = () =>{
    infx.classList.remove('jjc')
};


const scrollContentXElements = document.querySelectorAll('.scrollcontentX');
const imageDisplayDiv = document.querySelector('.rIhm');
const textDisplayDiv = document.querySelector('.nXam');
const infoDisplayDiv = document.querySelector('.vbnT');

scrollContentXElements.forEach(scrollContentX => {
    const openButton = scrollContentX.querySelector('.addBT');

    openButton.addEventListener('click', function() {
        const image = scrollContentX.querySelector('.im img');
        const text = scrollContentX.querySelector('.tx h3').textContent;
        const info = this.getAttribute('data-info');

        imageDisplayDiv.innerHTML = image.outerHTML;
        textDisplayDiv.innerHTML = text;
        infoDisplayDiv.textContent = info;
    });
});

