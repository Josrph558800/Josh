const e1 = document.querySelector('.e1')
if(e1 !== null){
e1.setAttribute('data-imgx', '<img src="foods/Eba.jpg">')
e1.setAttribute('data-name', 'Okra Soup')
e1.setAttribute('data-preparation', e1prep)
e1.setAttribute('data-ingredient', e1ing)
e1.setAttribute('data-steps', e1stps)
e1.setAttribute('data-duration', '1 hour 30 minutes')
}

const e2 = document.querySelector('.e2')
if(e2 !== null){
e2.setAttribute('data-imgx', '<img src="foods/Jollof-Rice.jpg">')
e2.setAttribute('data-name', 'Jellof-Rice')
e2.setAttribute('data-preparation', e2prep)
e2.setAttribute('data-ingredient', e2ing)
e2.setAttribute('data-steps', e2stps)
e2.setAttribute('data-duration', '20 to 30 minutes')
}

const e3 = document.querySelector('.e3')
if(e3 !== null){
e3.setAttribute('data-imgx', '<img src="foods/IMG_20201229_150727-1024x768.jpg">')
e3.setAttribute('data-name', 'Meat Pie')
e3.setAttribute('data-preparation', e3prep)
e3.setAttribute('data-ingredient', e3ing)
e3.setAttribute('data-steps', e3stps)
e3.setAttribute('data-duration', '1 hour 30 minutes')
}

const e4 = document.querySelector('.e4')
if(e4 !== null){
e4.setAttribute('data-imgx', '<img src="foods/Nigerian-Fried-Rice-960x960.jpg">')
e4.setAttribute('data-name', 'Nigerian-Fried-Rice')
e4.setAttribute('data-preparation', e4prep)
e4.setAttribute('data-ingredient', e4ing)
e4.setAttribute('data-steps', e4stps)
e4.setAttribute('data-duration', '1 hour 30 minutes')
}

const e5 = document.querySelector('.e5')
if(e5 !== null){
e5.setAttribute('data-imgx', '<img src="foods/Nigerian-Food-640x427.jpg">')
e5.setAttribute('data-name', 'Fisherman Soup')
e5.setAttribute('data-preparation', e5prep)
e5.setAttribute('data-ingredient', e5ing)
e5.setAttribute('data-steps', e5stps)
e5.setAttribute('data-duration', '1 hour 30 minutes')
}

const alsec = document.querySelectorAll('.valv')
alsec.forEach((mag)=>{
    mag.onclick = ()=>{
    const imgD = document.querySelector('.Rimg')
    const namD = document.querySelector('.RefN')
    const PreP = document.querySelector('.preT')
    const ingD = document.querySelector('.IngList')
    const stpsD = document.querySelector('.stepS')
    const duD = document.querySelector('.durA')
    
    const imgSrc = mag.getAttribute('data-imgx');
    const name = mag.getAttribute('data-name');
    const preparation = mag.getAttribute('data-preparation');
    const ingredient = mag.getAttribute('data-ingredient');
    const steps = mag.getAttribute('data-steps');
    const duration = mag.getAttribute('data-duration');

    imgD.innerHTML = imgSrc;
    namD.innerHTML = name; 
    PreP.innerHTML = preparation; 
    ingD.innerHTML = ingredient;
    stpsD.innerHTML = steps;
    duD.innerHTML = duration;
}
})
    if(window.innerWidth > 1004){
        const alse = document.querySelector('.valv')
        alse.click()    
    }
