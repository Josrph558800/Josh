const stylesheet = document.getElementById('theme-stylesheet');
const btx = document.querySelector(".mode img");
 
 function toggleDarkMode() {
    const isDarkMode = localStorage.getItem('darkMode');
    if (isDarkMode === 'true') {
      localStorage.setItem('darkMode', 'false');
      stylesheet.href = "theme/theme.css";
      localStorage.setItem('auto', 'false');
      btx.src = "SVG/dmx.svg";
    } else{
      localStorage.setItem('darkMode', 'true');
      stylesheet.href = "theme/DarkTheme.css";      
      localStorage.setItem('auto', 'false');
      btx.src = "SVG/dm.svg";
    }
  }
  
  const modTog = document.querySelector(".mode");
  modTog.onclick = ()=>{
      toggleDarkMode();
  };
  
  const isAuto = localStorage.getItem('auto');
  if(isAuto === 'true'){
      autoF();
  }else{
      dali();
  }
  
  function autoF() {
      stylesheet.href = "theme/auto.css";
  }
  
 function dali() {
  const isDarkMode = localStorage.getItem('darkMode');  
  if(isDarkMode === 'true' ) {
      stylesheet.href = "theme/DarkTheme.css";
      btx.src = "SVG/dm.svg"; 
  }else {
      stylesheet.href = "theme/theme.css"
      btx.src = "SVG/dmx.svg"; 
  }
 }

