{}function animateTextx(hi,spd) {
    const text = document.querySelector(".animated-textx");
    const textContent = hi;
    let speed = spd
    text.textContent = "";
    for (let i = 0; i < textContent.length; i++) {
        setTimeout(function () {
            text.textContent += textContent[i];
        }, speed * i)
    }
}

function next() {
    const inner = document.querySelectorAll('.inner')
    inner.forEach((innerx)=>{
    innerx.classList.toggle('inA')
   })
   animateText('Create your Account',50);
   animateTextx('Create your Password',50);
}

function validateForm(){
    const email = document.querySelector('#userN').value.trim();
    const password = document.querySelector('#password').value.trim();
 
    const em = document.querySelector('.un')
    const emL = document.querySelector('.un label')
    const sp = document.querySelector('.sp')
    const spL = document.querySelector('.sp label')
    
    if(email === ''){
        em.classList.add('error')
        animateText('invalid user name', 0);
        setTimeout(() => {
            em.classList.remove('error')       
        }, 1000);        
    }else if(email.length < 3){
        em.classList.add('error')
        animateText('invalid user name', 0);
        setTimeout(() => {
            em.classList.remove('error')  
        }, 1000);        
    }else if(email.length > 25){
        em.classList.add('error')
        animateText('invalid user name', 0);
        setTimeout(() => {
            em.classList.remove('error')         
        }, 1000);        
    }else if(password === ''){
        sp.classList.add('error')
        animateText('Invalid password', 0);
        setTimeout(() => {
            sp.classList.remove('error')        
        }, 1000);        
    }else{
        animateText('Please Wait...', 20);
        next()        
        console.log('user name is: ',email)
        console.log('email is: ', password)  
        localStorage.setItem('un', email)
        localStorage.setItem('em', password)     
    }
} 

function validateFormx(){
    const email = document.querySelector('#check').value.trim();
    const password = document.querySelector('#xcheck').value.trim();
 
    const em = document.querySelector('.vm')
    const emL = document.querySelector('.vm label')
    const sp = document.querySelector('.xm')
    const spL = document.querySelector('.xm label')
    
    if(email === ''){
        em.classList.add('error')
        animateTextx('Input a password', 0);
        setTimeout(() => {
            em.classList.remove('error')          
        }, 1000);        
    }else if(email.length < 8){
        em.classList.add('error')
        animateTextx('Password is too short', 0);
        setTimeout(() => {
            em.classList.remove('error')        
        }, 1000);        
    }else if(password === ''){
        sp.classList.add('error')
        animateTextx('Confirm Password', 0);
        setTimeout(() => {
            sp.classList.remove('error')
        }, 1000);        
    }else if(email !== password){
        sp.classList.add('error')
        animateTextx('Password mismatch', 0);
        setTimeout(() => {
            sp.classList.remove('error')        
        }, 1000);        
    }else if(email === '12345678'){
        sp.classList.add('error')
        animateTextx('Passwor is too easy', 0);
        setTimeout(() => {
            sp.classList.remove('error')        
        }, 1000);        
    }else{
        animateTextx('Please Wait...', 20);
        console.log('password is: ', password)
        console.log('new user created')
        loading()
        setTimeout(() => {
            window.location.href = 'Recipies.html' 
            localStorage.setItem('loged', 'true')  
            localStorage.setItem('pass', password)                 
        }, 1500);
    }
} 

const createAccountFormx = document.querySelector('.max')

createAccountFormx.addEventListener('submit', event => {
    event.preventDefault()
    validateForm()
})

const createAccountForm = document.querySelector('.maxx')

createAccountForm.addEventListener('submit', event => {
    event.preventDefault()
    validateFormx()
})

animateText('Create your Account',50);
animateTextx('Create your Password',50);
