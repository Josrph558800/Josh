
function offLoad() {
    setTimeout(function() {
    const loadingScreen = document.querySelector('.loading');
    loadingScreen.style.opacity = '0';
    setTimeout(function() {
      loadingScreen.style.display = 'none';
    }, 250);
  }, 250);
}

function Load() {
    setTimeout(function() {
    const loadingScreen = document.querySelector('.loading');
    loadingScreen.style.display = 'flex';
    setTimeout(function() {
      loadingScreen.style.opacity = '1';
    }, 100);
  }, 100);
}

function loading(){
  Load()
  setTimeout(() => {
    offLoad()
  }, 2000);
}

function navB() {
const alt = document.querySelector('.nTog')
const nv = document.querySelector('.navbar')
const ab = document.querySelector('#addB')
ab.onclick =()=>{
    question("To add a recipe you need to upgrade your account to pro account", ()=>{}, ()=>{setTimeout(outQuest,500)}, "Cancel", "Upgrade")
}
smc()
alt.onclick = () =>{
  smc()
  }
  function smc() {
    alt.classList.toggle('nAc')
    nv.classList.toggle('alt')
    setTimeout(() =>{
      nv.classList.remove('alt')
      alt.classList.remove('nAc')
    }, 8000)
  }
} 

function searchOut(){
  const searchB = document.querySelector('.up img')
  const searchX = document.querySelector('.searchpage')
  const XsearchX = document.querySelector('.iris')
  const Xcx = document.querySelector('.inSr a img')
  const categoriesS = document.querySelectorAll('.catg')
  const sip = document.querySelector('.inSr input')
  const resty = document.querySelector('.rmc')
  
  const categorie = document.querySelector('.catg')
  categorie.classList.toggle('hodx')

  categoriesS.forEach(catg => {
    catg.onclick = ()=>{
      catg.classList.toggle('hodx')
    }
  });

  XsearchX.onclick = () =>{
    searchX.classList.remove('Sx')
    sip.value = ''
    sip.blur()
  }
  
  Xcx.onclick = () =>{  
      if(sip.value !== '') {
      resty.style.display = 'flex'
      }else if(sip.value === ''){
          resty.style.display = 'none'
      }
  }      
  
  sip.onkeydown = (event)=>{
    if (event.key === "Enter") {
         if(sip.value !== '') {
      resty.style.display = 'flex'
      }else if(sip.value === ''){
          resty.style.display = 'none'
      }
    }
};

  searchB.addEventListener('click', () => {
    searchX.classList.add('Sx')
    setTimeout(()=>{
        sip.focus()
    }, 1000)
  })
}

function logout(){
const isLogin = localStorage.getItem('loged')
if(isLogin !== 'true') {
    outL()
    console.log('unauthorized access')
}
const lo = document.querySelector('#lo')
lo.onclick = () => { 
    outQuest()
}

}

function outQuest() {
    question('are you sure you want to log out from this session?',() =>{window.location.href = 'sign-up_login.html'; console.log('user logged out')},()=>{},'Yes','No')
}

function question(message, action, actionX, confirm, cancel){
  const conf = document.querySelector('.conf');
  const yes = document.querySelector('.yes');
  const no = document.querySelector('.no');
  const msg = document.querySelector('.confT');
  conf.classList.add('Qry');
  msg.textContent = message;
  yes.innerText = confirm
  no.innerText = cancel
  yes.style.display = 'block'
  no.onclick = () => {;
    actionX();
    conf.classList.remove('Qry');
  };
  yes.onclick = () => {
    action();
    conf.classList.remove('Qry');
  };
};

function questionX(message, action, confirm) {
  const conf = document.querySelector('.conf');
  const yes = document.querySelector('.yes');
  const no = document.querySelector('.no');
  const msg = document.querySelector('.confT'); 
  conf.classList.add('Qry');
  msg.textContent = message;
  yes.style.display = 'none'; 
  no.innerText = confirm
  no.onclick = () => {
    action();
    conf.classList.remove('Qry');
  };
};

function outL() {
  setTimeout(()=>{
      questionX("You can't access this app if you aren't logged in. Please login",() =>{window.location.href = 'sign-up_login.html'}, 'Login')
      window.history.pushState({}, '', 'sign-up_login.html');
  },0)
}


function imgLoad() {
    const imgsx = document.querySelectorAll('.vim img')
    const txz = document.querySelectorAll('.vtx h3, .vtx p')
    const txzb = document.querySelectorAll('.vtx')
    const imgsC = document.querySelectorAll('.Rimg img')
    imgsC.forEach((jex)=>{
            jex.style.display = 'none'            
          })
        window.addEventListener('load', ()=>{
            imgsx.forEach((jex)=>{
            jex.style.display = 'block' 
            jex.onerror = ()=>{
               jex.style.display = 'none'
            }
            })
            imgsC.forEach((jex)=>{
            jex.style.display = 'block' 
            jex.onerror = ()=>{
               jex.style.display = 'none'
            }
            })
            txz.forEach((jex)=>{
            jex.style.display = 'block'
            })
            txzb.forEach((jex)=>{
            jex.style.background = 'none'            
            })
            res()
            window.addEventListener('resize', () =>{
            res()            
            })            
        })
    }



document.addEventListener('contextmenu', function(event) {
    event.preventDefault();
});
