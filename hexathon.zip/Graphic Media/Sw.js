function playRole() {
    const all = document.querySelectorAll('.valv h2')

all.forEach( al =>{
    const body = document.querySelector('.body')
    const body1 = document.querySelector('.body1')
    const out = document.querySelector('.out')
    function trC(){
        body.classList.toggle('bodyA')
        body1.classList.toggle('body1A')
        out.classList.toggle('outA')
    }
    al.onclick = () =>{trC()};
    out.onclick = () =>{trC()};
})
}

function res(){
    if (window.innerWidth < 1004){
        playRole()
    }
}
