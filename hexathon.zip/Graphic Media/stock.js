const lik = document.querySelector(".lik");

lik.addEventListener("click", () => {
    const currentSrc = lik.src;
    const absoluteURL = new URL(currentSrc, window.location.href).href;

    if (absoluteURL.endsWith("SVG/liked.svg")) {
        lik.src = "SVG/like.svg";
    } else if (absoluteURL.endsWith("SVG/like.svg")) {
        lik.src = "SVG/liked.svg";
    }
});


const fav = document.querySelector(".fav");
fav.addEventListener("click", () => {
    const currentSrc = fav.src;
    const absoluteURL = new URL(currentSrc, window.location.href).href;

    if (absoluteURL.endsWith("SVG/fava.svg")) {
        fav.src = "SVG/favorite.svg";
    } else if (absoluteURL.endsWith("SVG/favorite.svg")) {
        fav.src = "SVG/fava.svg";
    }
});

const refreshButton = document.querySelector(".refh");
const imageContainer = document.querySelector(".Rimg");;

refreshButton.addEventListener('click', function() {
    const images = imageContainer.querySelectorAll('img');
    images.forEach(image => {
        const currentSrc = image.src;
        const rfh = document.querySelector(".refh");
        image.src = '';
        image.style.opacity = '0'
        image.src = currentSrc;
        rfh.style.animation = 'reload 1.5s linear'
        setTimeout(()=>{
            image.style.opacity = '1'
            rfh.style.animation = 'none'
        }, 1500);
    });
});
