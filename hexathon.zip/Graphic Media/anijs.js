const opt = document.querySelector(".bH")
const optx = document.querySelector(".bDr") 
const anix = document.querySelector(".animat")
const loadx = document.querySelector(".sld")
const sig = document.querySelector("#sig")
sig.onclick = () =>{
    window.location.href = "auth.html"
}

const log = document.querySelector("#log")
log.onclick = () =>{
    window.location.href = "authL.html"    
}

function animateText() {
    const text = document.querySelector(".animated-text");
    const textContent = text.textContent;
    let speed = 35
    text.textContent = "";
    for (let i = 0; i < textContent.length; i++) {
        setTimeout(function () {
            text.textContent += textContent[i];
        }, speed * i)
    }
}

function togal() {
   opt.classList.toggle("bHA")
  optx.classList.toggle("nxc")
  anix.classList.toggle("yx")   
}

function off() {
    const loadingScreen = document.querySelector('.loading');
    loadingScreen.style.opacity = '0';
    setTimeout(function() {
      loadx.classList.toggle("yx")
      loadingScreen.style.display = 'none';
    }, 500);
}

window.onload = ()=>{
    loadx.classList.toggle("yx")
}
 
 setTimeout(()=>{
  off()
  togal()
  animateText() 
 },3000)
 
 localStorage.setItem('auto', 'true');
  stylesheet.href = "theme/auto.css";
  localStorage.setItem('loged', 'false')
  localStorage.removeItem('prfImg');
  localStorage.removeItem('un')
  localStorage.removeItem('em')
  localStorage.removeItem('pass')